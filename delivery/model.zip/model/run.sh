#!/bin/bash

PROCESSOR="-processor SingleIndividualProcessor"
CONFIGS_PATH="-configPath Experiments"
CONFIG=""
STATISTICS="-statisticExporters CellMovementExporter"
SEED="-indSeedNum 1"

welcome_screen () {
        echo
        echo
        echo "+-+-+-+-+-+ +-+ +-+-+-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+"
        echo "|B|C|N|N|M| |@| |J|e|t|B|r|a|i|n|s| |R|e|s|e|a|r|c|h|"
        echo "+-+-+-+-+-+ +-+ +-+-+-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+"
        echo
        user_dialog
}

user_dialog () {
        echo "Welcome to BCNNM Simulation runner."
        echo "Available actions:"
	echo "0. Check Java version"
        echo "1. Run Configuration I short (200k ticks)"
        echo "2. Run Configuration I long (3m ticks)"
        echo "3. Run Configuration II short (200k ticks)"
        echo "4. Run Configuration II long (3m ticks)"
        echo "5. Exit"
	user_input
} 

user_input () {
        read -p "Please, select an action: " selection
        
        case $selection in
                0)
                        check_java
			user_input
                        ;;
                1)
         		CONFIG="Configuration-1/A"               
                        ;;
                2)
			CONFIG="Configuration-1/B"
                        ;;      
                3)
			CONFIG="Configuration-2/A"
                        ;;
                4)
			CONFIG="Configuration-2/B"
                        ;;

                5)
                        exit
                        ;;
                *)
                        echo "Wrong input"
                        exit
                        ;;
        esac
	run_simulation
}

run_simulation() {
	java -Xmx14g -Xms1g -jar SimulationModel-all.jar $PROCESSOR $CONFIGS_PATH/$CONFIG $STATISTICS $SEED
}

check_java () {
	if type -p java; then
    		echo found java executable in PATH
    		_java=java
	elif [[ -n "$JAVA_HOME" ]] && [[ -x "$JAVA_HOME/bin/java" ]];  then
    		echo found java executable in JAVA_HOME...     
    		_java="$JAVA_HOME/bin/java"
	else
    		echo "Java Virtual Machine not found, please install OpenJDK 8+ or Oracle Java 8+."
    		exit
	fi

	if [[ "$_java" ]]; then
	    	version=$("$_java" -version 2>&1 | awk -F '"' '/version/ {print $2}')
	    	echo version "$version"
    		if [[ "$version" > "1.8" ]]; then
        		echo version is okay...
    		else         
        		echo Version is not okay, please update your JVM.
        		exit
    		fi
	fi

	
}

welcome_screen
